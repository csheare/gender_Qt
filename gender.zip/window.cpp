
#include <QtWidgets>
#include <QLabel>
#include <QPushButton>
#include <QTextEdit>
#include <QComboBox>

#include "window.h"


Window::Window()
{
    createGUI();
}

void Window::createGUI()
{
    QGridLayout *layout = new QGridLayout;

    //add name label
    QLabel *label = new QLabel();
    QString name = "Name: ";
    label->setText(name);
    layout->addWidget(label,0,0);

    //add text box
    QTextEdit *te = new QTextEdit();
    //qe->placeholderText("Type your name here!");
    layout->addWidget(te,1,0);

    //Add gender combo box
    QComboBox *qb = new QComboBox();
    qb->insertItem(0,"male");
    qb->insertItem(1,"female");
    layout->addWidget(qb,2,0);

    //add button
    QPushButton *button = new QPushButton("OK");
    layout->addWidget(button,3,0);
    setLayout(layout);

    setWindowTitle(tr("Gender"));
}

